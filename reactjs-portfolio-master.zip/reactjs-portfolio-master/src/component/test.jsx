import React from "react";

class Test extends React.Component {
	render() {
		return <h1>Hello</h1>;
	}
}

export default Test;
